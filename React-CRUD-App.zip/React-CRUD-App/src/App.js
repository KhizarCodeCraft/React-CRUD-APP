import {
  BrowserRouter as Router,
  Route,
  Switch
} from "react-router-dom";
import "../node_modules/bootstrap/dist/css/bootstrap.css";
import AddUser from './User/AddUser';
import EditUser from './User/EditUser';
import User from './User/User';
import Home from './Page/Home';

function App() {
  return (
     <Router>
      <div className="App">

        <Switch>
          <Route exact path="/" component={Home} />
          {/* <Route exact path="/about" component={About} /> */}
          <Route exact path="/users/add" component={AddUser} />
           <Route exact path="/users/edit/:id" component={EditUser} />
          <Route exact path="/users/:id" component={User} />
          {/* <Route component={NotFound} />  */}
        </Switch>
      </div>
    </Router>
  );
}

export default App;
